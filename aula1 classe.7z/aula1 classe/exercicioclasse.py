class Dados():
    def __init__(self, nome, idade):
        self.nome = nome
        self.idade = idade
    def exibir(self):
        print(f'Olá, sou o {self.nome} e tenho {self.idade} anos.')
p1 = input('Diga o meu nome: ')
p2 = int(input('Diga minha idade: '))
pessoa1 = Dados(p1, p2)
pessoa1.exibir()