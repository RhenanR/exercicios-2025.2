class Conta:
    def __init__(self, titular):
        self.titular = titular
        self.saldo = 0
    def depositar(self, valor):
        self.saldo += valor
        print(f'Seu saldo é: {self.saldo}')
conta1 = Conta('Katarina Martha')
while True:
    pergunt1 = float(input(f'{conta1.titular} deseja depositar quanto? '))
    conta1.depositar(pergunt1)
    pergunt2 = input('deseja depositar mais? [S/N]')
    if pergunt2 in 'Nn':
        break