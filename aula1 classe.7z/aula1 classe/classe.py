class Vendas():
    def __init__(self, nome):
        self.nome = nome
        self.vendas = ()
    def vendeu(self, vendas):
        self.vendas = vendas
    def bateuMeta(self, meta):
        if self.vendas >= meta:
            print(f'{self.nome} Bateu a Meta')
        else:
            print(f'{self.nome} não bateu a meta')
vendedor = Vendas('Marcelo do tigrinho')
vendedor.vendeu(2222)
vendedor.bateuMeta(555)