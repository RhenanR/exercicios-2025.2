class Cubo:
    def __init__(self, valor):
        self.x = valor
        print('Metodo executado')
    def calcularCubo(self):
        cubo = self.x * self.x * self.x
        return f'Cube calculado: {cubo}'
cubo = Cubo(int(input('Digite um valor para saber o cubo: ')))
calculo = cubo.calcularCubo()
print(calculo)
cubo2 = Cubo(50)
print(cubo2)